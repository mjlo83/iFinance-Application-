package se2203b.assignments.ifinance;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

//this is the AccountGroupsController class for Assigment 4
//I just started making this before I saw there was already a class made for it
//so this is the replacement :)
public class GroupsController implements Initializable {


  //create observable lists for categories and groups
    final ObservableList<AccountCategory> categories = FXCollections.observableArrayList();
    final ObservableList<Group> groups = FXCollections.observableArrayList();

    //declare fxmls
    @FXML
    Button exitButton;
    @FXML
    TreeView<Group> treeViewChart = new TreeView<>();

    @FXML
    MenuItem addGroup=new MenuItem("Add New Group");

    @FXML
    MenuItem changeGroup = new MenuItem("Change Group Name");
    @FXML
    MenuItem deleteGroup = new MenuItem("Delete Group");

    @FXML
    TextField groupNameField;


    GroupsAdapter groupAdapter;

    AccountCategoryAdapter accountCategoryAdapter;

    IFinanceController iFinanceController;


    TreeItem<Group> currentItem= new TreeItem<>(new Group());



    boolean performChange = false;

    boolean performAdd = false;

    //set adapter
    public void setAdapters(GroupsAdapter groupAdapter, AccountCategoryAdapter accountCategoryAdapter) throws SQLException {
        this.groupAdapter = groupAdapter;
        this.accountCategoryAdapter = accountCategoryAdapter;

        createData();

    }
    //close stage on exit
    public void exit(){
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }

    //save and update from textField for change and add group
    public void save() throws SQLException {
        //add group
        if (performAdd) {
            TreeItem<Group> newGroup = groupAdapter.addGroups(currentItem.getValue(), groupNameField.getText());
            currentItem.getChildren().add(newGroup);
            // change group name
        } else if (performChange) {
            TreeItem<Group> newGroup = groupAdapter.changeGroup(currentItem.getValue(), groupNameField.getText());
            currentItem.setValue(newGroup.getValue());
        }
        //clear field
        groupNameField.clear();
        performAdd = false;
        performChange = false;
        treeViewChart.refresh();
    }

    //check if user has selected an account category
    private boolean selectAccountCategory() {
        //returns if the tree item selected by the user is an account type
        if(currentItem.getValue().getName().equals("Assets") ||
                currentItem.getValue().getName().equals("Liabilities") ||
                currentItem.getValue().getName().equals("Income") ||
                currentItem.getValue().getName().equals("Expenses")){
            return true;
        }
        return false;
    }

    //on action for if user selects category, return options
    public void selectItem() {
        //check item selected
        TreeItem<Group> checkNull = treeViewChart.getSelectionModel().getSelectedItem();
        if (checkNull != null) {
            currentItem = checkNull;
            if (currentItem.isLeaf() && currentItem.getChildren().size() > 0) {
                deleteGroup.setDisable(true);
            } else {
                deleteGroup.setDisable(false);
            }
        } else {
            deleteGroup.setDisable(true);
        }
        //if account category do not allow to delete or change
        if (selectAccountCategory()) {
            changeGroup.setDisable(true);
            deleteGroup.setDisable(true);
        } else {
            changeGroup.setDisable(false);
            if (currentItem == null || !currentItem.getChildren().isEmpty()) {
                deleteGroup.setDisable(true);
            } else {
                deleteGroup.setDisable(false);
            }
        }
    }



    //set controller
    public void setIFinanceController(IFinanceController controller) {
        iFinanceController = controller;

    }

    //build/create data items setting category and updating tree view chart

    public void createData() throws SQLException {
        groups.addAll(groupAdapter.getGroupsList());
        categories.addAll(accountCategoryAdapter.getCategoriesList());

        // create the root node
        TreeItem<Group> rootItem = new TreeItem<>(new Group());

        // add categories as children of root node
        for (AccountCategory category : categories) {
            TreeItem<Group> categoryItem = new TreeItem<>(new AccountCategory(category.getName(), category.getType()));
            rootItem.getChildren().add(categoryItem);

            // add groups as children of category item
            for (Group group : groups) {
                if (group.getParent() == null && group.getElement().getName().equals(categoryItem.getValue().getName())) {
                    // group has no group parent, so its parent is the category
                    TreeItem<Group> groupItem = new TreeItem<>(group);
                    categoryItem.getChildren().add(groupItem);

                    // recursively add children of group item
                    addChildren(groupItem, group);
                }
            }
        }

        treeViewChart.setRoot(rootItem);
        treeViewChart.setShowRoot(false);
    }

    //add children recursively
    private void addChildren(TreeItem<Group> parentItem, Group parentGroup) {
        for (Group group : groups) {
            if (group.getParent() != null && group.getParent().getName().equals(parentGroup.getName())) {
                // set group parent
                TreeItem<Group> groupItem = new TreeItem<>(group);
                parentItem.getChildren().add(groupItem);

                // add children of group
                addChildren(groupItem, group);
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ContextMenu contextMenu = new ContextMenu();


        //handle add
        addGroup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                performAdd=true;
                performChange=false;
                groupNameField.requestFocus();
            }
        });


        //handle change
        changeGroup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                performAdd=false;
                performChange=true;
                groupNameField.requestFocus();
            }
        });

        //handle delete
        deleteGroup.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    groupAdapter.removeGroup(currentItem.getValue());
                    currentItem.getParent().getChildren().remove(currentItem);
                    currentItem.setValue(null);
                    treeViewChart.refresh();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        contextMenu.getItems().addAll(addGroup, changeGroup, deleteGroup);
        treeViewChart.setContextMenu(contextMenu);

    }
}


