package se2203b.assignments.ifinance;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AccountCategoryAdapter {
    Connection connection;
    public AccountCategoryAdapter(Connection conn, Boolean reset) throws SQLException {
        connection = conn;
        if (reset) {
            Statement statement = connection.createStatement();
            try {
                statement.execute("DROP TABLE Categories");
            } catch (SQLException ex) {
                //
            } finally {
                statement.close();
            }
            statement = connection.createStatement();
            try {
                statement.execute("CREATE TABLE Categories (Name VARCHAR(20), Type VARCHAR(20))");
                this.insertCategory("Assets","Debit");
                this.insertCategory("Liabilities","Credit");
                this.insertCategory("Income","Credit");
                this.insertCategory("Expenses","Debit");
            } catch (SQLException ex) {
                //
            } finally {
                statement.close();
                connection.close();
            }
        }
    }
    public void insertCategory(String name, String type) throws SQLException {
        Statement stmt = connection.createStatement();

        stmt.executeUpdate("INSERT INTO Categories (Name, Type) "
                + "VALUES ('" + name + "','" + type + "')");

    }
    public ObservableList<AccountCategory> getCategoriesList() throws SQLException {
        ObservableList<AccountCategory> categoryList = FXCollections.observableArrayList();

        Statement stmt = connection.createStatement();
        String str = "SELECT * FROM Categories";
        ResultSet rs = stmt.executeQuery(str);
        while(rs.next()) {
            categoryList.add(new AccountCategory(rs.getString("Name"), rs.getString("Type")));
        }
        return categoryList;
    }
}
