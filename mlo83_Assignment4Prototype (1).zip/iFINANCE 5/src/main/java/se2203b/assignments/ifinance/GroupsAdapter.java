package se2203b.assignments.ifinance;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TreeItem;

import java.sql.*;

public class GroupsAdapter {
    Connection connection;



    public GroupsAdapter(Connection conn, Boolean reset) throws SQLException {

        connection = conn;
        if (reset) {
            Statement statement = null;
            try {
                statement = connection.createStatement();
                statement.execute("DROP TABLE IF EXISTS Groups");

                statement.execute("CREATE TABLE Groups (GroupID INT, GroupName VARCHAR(30), GroupParent INT REFERENCES Groups(GroupID), GroupElement VARCHAR(30) REFERENCES Categories(Name))");
                //populate groups table to match given excel sheet

                this.insertGroup(1,"Fixed Assets",0,"Assets");
                this.insertGroup(2,"Investments",0,"Assets");
                this.insertGroup(3,"Branch/divisions",0,"Assets");
                this.insertGroup(4,"Cash in hand",0,"Assets");
                this.insertGroup(5,"Bank accounts",0,"Assets");
                this.insertGroup(6,"Deposits (assets)",0,"Assets");
                this.insertGroup(7,"Advances (assets)",0,"Assets");
                this.insertGroup(8,"Capital account",0,"Liabilities");
                this.insertGroup(9,"Long term loans",0,"Liabilities");
                this.insertGroup(10,"Current liabilities",0,"Liabilities");
                this.insertGroup(11,"Reserves and surplus",0,"Liabilities");
                this.insertGroup(12,"Sales account",0,"Income");
                this.insertGroup(13,"Purchase account",0,"Expenses");
                this.insertGroup(14,"Expenses (direct)",0,"Expenses");
                this.insertGroup(15,"Expenses (indirect)",0,"Expenses");
                this.insertGroup(16,"Secured loans",9,"Liabilities");
                this.insertGroup(17,"Unsecured loans",9,"Liabilities");
                this.insertGroup(18,"Duties taxes payable",10,"Liabilities");
                this.insertGroup(19,"Provisions",10,"Liabilities");
                this.insertGroup(20,"Sundry creditors",10,"Liabilities");
                this.insertGroup(21,"Bank od & limits",10,"Liabilities");
            } catch (SQLException ex) {
                //
            } finally {

                if (statement != null) {
                    statement.close();
                }
            }
            connection.close();
        }
    }

    //create insertgroup function to populate table with above  statements
    public void insertGroup(int groupID, String groupName, int groupParent, String groupElement) throws SQLException {
        Statement stmt = connection.createStatement();

        stmt.executeUpdate("INSERT INTO Groups (GroupID, GroupName, GroupParent, GroupElement) "
                + "VALUES (" + groupID + ",'" + groupName + "',"+ groupParent +",'"+ groupElement +"')");

    }

    //delete group
    public void deleteGroups(int groupId) throws SQLException {
        Statement stmt = connection.createStatement();
        String str = "DELETE FROM Groups WHERE GroupID= "+groupId;
        stmt.executeUpdate(str);;
    }
    public void modifyGroups(int groupID, String groupName) throws SQLException {
        Statement stmt = connection.createStatement();
        String str = "UPDATE Groups SET GroupName='"+groupName+"' WHERE GroupID= "+groupID;
        stmt.executeUpdate(str);
    }

    //create addGroup function to be used in controller to add group
    public TreeItem<Group> addGroups(Group group, String newName) throws SQLException {
        int parentID = group.getID();
        int newGroupID = HighestID() + 1;
        AccountCategory accountCategory = group.getElement();
        if (accountCategory == null) {
            accountCategory = (AccountCategory) group;
        }
        TreeItem<Group> newGroup = new TreeItem<>(new Group(newGroupID, newName, group, accountCategory));
        if (parentID != 0) {
            // The group has a parent
            this.insertGroup(newGroupID, newName, parentID, accountCategory.getName());
        } else {
            // The group does not have a parent
            this.insertGroup(newGroupID, newName, 0, accountCategory.getName());
        }

        // Add new group to the database and update its parent ID if it has one
        String updateStatement = "UPDATE Groups SET GroupParent = ? WHERE GroupID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(updateStatement)) {
            pstmt.setInt(1, parentID);
            pstmt.setInt(2, newGroupID);
            pstmt.executeUpdate();
        }

        return newGroup;
    }

    //create change group name function to call in controller
    public TreeItem<Group> changeGroup(Group group, String newName) throws SQLException {
        //Set new name
        group.setName(newName);

        // Update the name of the group
        this.modifyGroups(group.getID(), newName);

        // Create new TreeItem with the updated group
        TreeItem<Group> updatedGroup = new TreeItem<>(group);

        //return update
        return updatedGroup;
    }

    //create remove group function
    public void removeGroup(Group group) throws SQLException {
        int groupID = group.getID();
        //call delete group
        this.deleteGroups(groupID);
    }

    //get group list function
    public ObservableList<Group> getGroupsList() throws SQLException {
        ObservableList<Group> groupList = FXCollections.observableArrayList();

        // Retrieve Group Table data
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Groups");

        // Loop through result set
        while (rs.next()) {
            //add group to list
            int groupID = rs.getInt("GroupID");
            String groupName = rs.getString("GroupName");
            int groupParentID = rs.getInt("GroupParent");

            //retrieve AccountCategory object from Categories
            String categoryName = rs.getString("GroupElement");
            Statement stmt2 = connection.createStatement();
            ResultSet rs2 = stmt2.executeQuery("SELECT * FROM Categories WHERE Name='" + categoryName + "'");
            if (rs2.next()) {
                String categoryType = rs2.getString("Type");
                AccountCategory category = new AccountCategory(categoryName, categoryType);

                // check for Group parent
                Group groupParent = null;

                //not null
                if (groupParentID != 0) {
                    Statement stmt3 = connection.createStatement();
                    ResultSet rs3 = stmt3.executeQuery("SELECT * FROM Groups WHERE GroupID=" + groupParentID);
                    if (rs3.next()) {
                        groupParent = new Group(rs3.getInt("GroupID"), rs3.getString("GroupName"), null, null);
                    }
                    rs3.close();
                    stmt3.close();
                }

                // Create new Group object
                Group group = new Group(groupID, groupName, groupParent, category);
                //add to list
                groupList.add(group);
            }
            rs2.close();
            stmt2.close();
        }
        rs.close();
        stmt.close();
        return groupList;
    }

    //create search for HighestID function to set new ID for add group function
    public int HighestID() throws SQLException {
        int highest = 0;

        //searching for the highest ID
        for(int i = 1; i<getGroupsList().size(); i++){
            if(getGroupsList().get(i).getID() > getGroupsList().get(highest).getID()){
                highest = i;
            }

        }
        return getGroupsList().get(highest).getID() + 1;//returns highest ID + 1
    }
}
